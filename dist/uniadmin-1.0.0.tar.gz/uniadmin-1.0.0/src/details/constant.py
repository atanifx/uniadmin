BASE_URL = "https://www.uniport.edu.ng/news/latestnews/2000-2021-2022-admission-list-batch4.html"

URL = "https://aris.uniport.edu.ng/admissionregistration"
